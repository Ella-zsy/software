export default {
  m: {
    menuName: '菜单名称',
    menuState: '菜单状态',
    icon: '图标',
    menuid: '菜单id',
    menuType: '菜单类型',
    sort: '排序',
    authorityID: '权限标识',
    componentPath: '组件路径',
    isShow: '是否显示',
    parentMenu: '上级菜单',
    directory: '目录',
    menu: '菜单',
    button: '按钮',
    link: '链接',
    isFrame: '是否外链',
    routePath: '路由地址',
    permissionStr: '权限字符',
    isCache: '是否缓存',
    menuNameKey: '菜单名(key)',
  }
}