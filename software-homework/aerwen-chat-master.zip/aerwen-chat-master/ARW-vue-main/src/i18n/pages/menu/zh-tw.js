export default {
  m: {
    menuName: '菜單名稱',
    menuState: '菜單狀態',
    icon: '圖標',
    menuid: '菜單id',
    menuType: '菜單類型',
    sort: '排序',
    authorityID: '權限標識',
    componentPath: '組件路徑',
    isShow: '是否顯示',
    parentMenu: '上級菜單',
    directory: '目錄',
    menu: '菜單',
    button: '按鈕',
    link: '鏈接',
    isFrame: '是否外鏈',
    routePath: '路由地址',
    permissionStr: '權限字符',
    isCache: '是否緩存',
    menuNameKey: '菜單名(key)',
  }
}