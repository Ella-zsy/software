export default {
  m: {
    menuName: 'menuName',
    menuState: 'menuState',
    icon: 'icon',
    menuid: 'menuid',
    menuType: 'menuType',
    sort: 'sort',
    authorityID: 'authorityID',
    componentPath: 'componentPath',
    isShow: 'isShow',
    parentMenu: 'parentMenu',
    directory: 'directory',
    menu: 'menu',
    button: 'button',
    link: 'link',
    isFrame: 'isFrame',
    routePath: 'routePath',
    permissionStr: 'permission',
    isCache: 'isCache',
    menuNameKey: 'menuNameKey',
  }
}